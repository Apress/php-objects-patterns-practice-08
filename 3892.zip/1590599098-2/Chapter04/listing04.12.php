<?php
final class Checkout {
    // ...
}

class IllegalCheckout extends Checkout {
    // ...
}

$checkout = new Checkout();

?>
