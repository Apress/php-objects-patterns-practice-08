<?php
class ShopProduct {
    const AVAILABLE      = 0;
    const OUT_OF_STOCK   = 1;
    public $status;
}
print ShopProduct::AVAILABLE;
?>
