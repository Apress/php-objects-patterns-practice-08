Most listings are straight PHP files, and are designed to be run from the
command line.

Some examples assume pre-existing databases or other dependencies. Where 
I created rough scripts to construct dependencies I have left these in 
place. I have placed die statements at the top to prevent accidental 
execution. Setup scripts were designed for the author's use only -- they 
are not intended to work in any other context.

All code is illustrative only. It is not intended for deployment.
