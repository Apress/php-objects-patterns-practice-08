<?php
class ShopProduct {
    // class body
}
$product1 = new ShopProduct();
$product2 = new ShopProduct();

var_dump($product1);
var_dump($product2);

// output:
// object(ShopProduct)#1 (0) {
// }
// object(ShopProduct)#2 (0) {
// }
?>
