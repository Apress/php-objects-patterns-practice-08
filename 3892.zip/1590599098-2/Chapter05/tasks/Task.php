<?php

class Task {
    function doSpeak() {
        print "hello\n";
    }
}
?>
