<?php
namespace test::smithco;
import PHPUnit::Framework::MockObject::Matcher::StatelessInvocation;
require_once( "listing05.07.php" );

class myStatelessInvocation extends StatelessInvocation {
    //...
}

$x = new myStatelessInvocation();



?>
