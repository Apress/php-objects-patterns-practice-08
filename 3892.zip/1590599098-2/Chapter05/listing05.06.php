<?php
namespace PHPUnit::Framework::MockObject::Matcher;

interface Invocation {

}
?>
