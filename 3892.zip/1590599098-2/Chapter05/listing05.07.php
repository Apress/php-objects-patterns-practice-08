<?php
namespace PHPUnit::Framework::MockObject::Matcher;
require_once( 'listing05.06.php' ); 

abstract class StatelessInvocation implements Invocation {

}

//Reflection::Export( new ReflectionClass( __NAMESPACE__."::Invocation" ) );
?>
