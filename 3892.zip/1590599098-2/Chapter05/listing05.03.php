<?php
namespace business;

class user {
    //...
}
?>
