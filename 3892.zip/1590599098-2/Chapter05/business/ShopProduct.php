<?php
class business_ShopProduct {
    private $title;
    private $producerMainName;
    private $producerFirstName;
    protected $price;
    private $discount = 0; 
    
    public function __construct( )  {

    }

}
?>
