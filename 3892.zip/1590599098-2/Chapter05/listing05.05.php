<?php
require_once( "listing05.03.php" );
require_once( "listing05.04.php" );

$fuser = new business::user();

?>
