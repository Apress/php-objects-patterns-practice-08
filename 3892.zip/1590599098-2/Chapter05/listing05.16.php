<?php
require_once( 'business/ShopProduct.php' );

print_r( get_declared_classes() );
?>
