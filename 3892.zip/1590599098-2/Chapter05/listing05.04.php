<?php
namespace forum;

class user {
    //...
}
?>
