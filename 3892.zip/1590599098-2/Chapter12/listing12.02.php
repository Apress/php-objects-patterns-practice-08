<?php
require_once("listing12.01.php");
import woo::controller::ApplicationController as ApplicationController;

$c = new ApplicationController();
?>
