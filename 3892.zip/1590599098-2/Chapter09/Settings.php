<?php

class Settings {
    static $COMMSTYPE = 'Mega';
}
?>
