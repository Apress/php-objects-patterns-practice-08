<?php
require_once( "woo/controller/Controller.php"); // using the real one now
woo_controller_Controller::run();
?>
