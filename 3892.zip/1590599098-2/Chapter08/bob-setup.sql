INSERT INTO db VALUES ('localhost','bobs_db','bob','Y','Y','Y','Y','Y','Y','N','N','N','N');
INSERT INTO user VALUES ('localhost','bob', password('bobs_pass'),'N','N','N','N','N','N','N','N','N','N','N','N','N','N');
