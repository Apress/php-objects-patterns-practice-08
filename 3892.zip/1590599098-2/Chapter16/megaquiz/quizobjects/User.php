<?php
/**
 * @license   http://www.example.com Borsetshire Open License
 * @package  quizobjects 
 */


/**
 * @package  quizobjects 
 */
class User {}
?>
